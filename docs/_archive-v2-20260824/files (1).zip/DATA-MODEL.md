# DeAcademy — Data Model & Database Schema (v2)

Entitas inti, field kunci, dan relasi antar tabel — mencakup seluruh 8 portal final. PostgreSQL direkomendasikan (Row-Level Security untuk kebutuhan multi-tenant). Lihat `erd.mermaid` untuk diagram visual.

---

## 1. Identity & Access

### `users`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| full_name | text | |
| email | text unique | |
| password_hash | text | |
| user_type | enum | `individual`, `corporate_employee`, `staff`, `verifier_user` |
| company_id | uuid FK nullable | null jika individual |
| position | text | jabatan/level (untuk analytics) |
| department | text nullable | hanya relevan untuk corporate_employee |
| region | text | untuk analytics sebaran wilayah |
| years_experience | int nullable | untuk talent search & public verification page |
| created_at | timestamp | |

### `employee_profiles` (extension untuk corporate_employee)
| Field | Type | Note |
|---|---|---|
| user_id | uuid PK/FK | |
| employee_id | text | **unik per company_id**, bukan global — validasi saat create |
| UNIQUE(company_id, employee_id) | constraint | mencegah duplikat ID dalam satu perusahaan |

### `roles` & `user_roles`
Sama seperti v1 — `participant`, `operator`, `tutor`, `examiner`, `corporate_admin`, `verifier`.

### `staff_assignments`
Sama seperti v1 (role tutor/examiner per training/cohort).

---

## 2. Companies (Multi-Tenant Core)

### `companies`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| name | text | |
| industry | text | |
| source | enum | `self_registered`, `operator_assigned` |
| status | enum | `pending_activation`, `active`, `suspended` |
| account_manager_id | uuid FK → users | |
| pic_name | text | |
| pic_email | text | |
| satisfaction_score | numeric nullable | dari survei periodik |

### `company_seats`
Sama seperti v1 (seats_purchased, seats_used).

---

## 3. Trainings & Curriculum

### `trainings`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| title, category, level, format, duration_label | text/enum | |
| price | numeric | 0 jika internal/free |
| cpd_hours | int | |
| description, objectives[], prerequisites, audience | text | |
| status | enum | `draft`, `published` |
| visibility | enum | `public`, `internal` |
| owner_company_id | uuid FK nullable | **wajib jika visibility=internal** |
| created_by | uuid FK → users | |
| next_batch_date | date nullable | |
| seats | int nullable | |

> **Multi-tenant kritis**: training `visibility=internal` HARUS difilter `owner_company_id = current_user.company_id` via RLS. Operator DeAcademy tidak diberi akses baca konten (description/objectives/syllabus/lesson content) untuk training internal — hanya metadata agregat (jumlah training, jumlah enrollment) untuk billing/kapasitas.

### `training_related_trainings` (BARU)
| Field | Type | Note |
|---|---|---|
| training_id | uuid FK → trainings | |
| related_training_id | uuid FK → trainings | |
| source | enum | `manual` (dipilih operator via search), `suggested_category` (auto-suggest, tetap perlu diklik/approve operator) |
| created_by | uuid FK → users | operator yang menambahkan |
| created_at | timestamp | |

> Self-referential many-to-many. Relasi ini **tidak otomatis dua arah** — kalau A dikaitkan ke B, tidak berarti B otomatis muncul terkait A, kecuali operator menambahkannya juga saat mengedit B. Basis untuk "Recommended for You" di dashboard peserta: query semua `training_related_trainings` di mana `training_id` = training yang sudah diselesaikan/di-enroll peserta, lalu tampilkan `related_training_id` yang belum mereka ambil.

### `syllabus_modules`, `syllabus_topics`
Sama seperti v1.

### `lessons`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| module_id | uuid FK | |
| type | enum | `lesson`, `quiz`, `exercise`, `workshop`, `exam` |
| content_type | enum nullable | `video`, `slides` (hanya type=lesson) |
| video_asset_url | text nullable | |

### `lesson_slides`
Sama seperti v1 (per-slide title, bullets, audio_asset_url).

### `quizzes` / `quiz_questions`
Sama seperti v1, dengan `pass_score`.

### `exercise_resources` / `workshop_resources`
Sama seperti v1 (reference PDF + template file).

---

## 4. Enrollment & Progress

### `enrollments`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| user_id | uuid FK | |
| training_id | uuid FK | |
| status | enum | `upcoming`, `in_progress`, `completed` |
| assigned_by | uuid FK nullable | untuk assignment korporat |
| deadline | date nullable | |
| enrolled_at, completed_at | timestamp | |
| **completed_on_time** | boolean nullable | computed: `completed_at <= deadline` — basis analytics on-time vs late |

### `lesson_progress`
Sama seperti v1.

### `quiz_attempts`
| Field | Type | Note |
|---|---|---|
| ... | | sama seperti v1 |
| is_practice | boolean | percobaan setelah lulus resmi tidak mengubah status |

### `exercise_submissions` / `workshop_submissions`
| Field | Type | Note |
|---|---|---|
| ... | | sama seperti v1 |
| status | enum | `submitted`, `reviewed`, `revision_requested` |
| replaced_at | timestamp nullable | untuk fitur "replace submission" sebelum direview |

### `exam_attempts`
Sama seperti v1 (auto_score, decision, examiner_id, examiner_comment).

---

## 5. Certificates & CPD (Diperluas)

### `certificates`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| user_id | uuid FK | |
| training_id | uuid FK nullable | null jika upload manual |
| name, issuer | text | |
| source | enum | `lms`, `manual`, `internal_corporate` |
| issued_at | date | |
| expires_at | date nullable | |
| requires_cpd | boolean | |
| cpd_required_annual | int nullable | |
| **status** | enum | `active`, `grace_period`, `suspended`, `lapsed` (jika requires_cpd) **atau** `active`, `attestation_due`, `dormant` (jika tidak) |
| grace_days_left | int nullable | |
| next_relevance_check_date | date nullable | untuk sertifikat non-CPD, siklus 3 tahun |

### `cpd_cycles` / `cpd_activities`
Sama seperti v1.

### `competency_currency_attestations` (BARU)
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| certificate_id | uuid FK | |
| evidence_type | enum | `project_log`, `workload_letter`, `work_sample` |
| file_url | text | |
| note | text | |
| verified_by | enum | `self_attested`, `employer_verified`, `operator_verified` |
| cosigned_by_user_id | uuid FK nullable | PIC yang co-sign, jika employer_verified |
| submitted_at | timestamp | |
| verified_at | timestamp nullable | |

---

## 6. Membership, Billing & Verification Marketplace

### `memberships`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| user_id | uuid FK | |
| plan | enum | `free`, `premium` |
| price, billing_cycle | numeric/enum | |
| renewal_date | date | |
| auto_renew | boolean | |
| payment_method_token | text | |

### `membership_invoices`
Sama seperti v1.

### `portfolio_settings`
| Field | Type | Note |
|---|---|---|
| user_id | uuid PK/FK | |
| is_public | boolean | |
| **consent_level** | enum | `full`, `partial`, `request_based` |
| public_slug | text unique | |

### `certificate_visibility`
Sama seperti v1 (per-certificate toggle untuk portfolio publik).

### `profile_views` (BARU)
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| participant_user_id | uuid FK | |
| viewer_verifier_account_id | uuid FK nullable | null jika via public link tanpa akun |
| source | enum | `public_link`, `employer_search` |
| viewed_at | timestamp | |

> Basis untuk "Your Visibility" di dashboard peserta (views bulan ini, breakdown sumber) dan "Talent Profile Views" di dashboard employer.

### `verifier_accounts`
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| company_name | text | |
| plan | enum | `pay_per_request`, `subscription` |
| price, renewal_date | numeric/date | |

### `verification_requests`
Sama seperti v1 (status pending/approved/denied, payment_status).

### `verifier_search_history` (BARU)
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| verifier_account_id | uuid FK | |
| competency_searched | text | |
| region_searched | text nullable | |
| experience_filter | text nullable | |
| results_count | int | |
| matched | boolean | `results_count > 0` |
| searched_at | timestamp | |

> Basis untuk "Search Match Rate & Skill Gap" — agregasi `matched=false` per `competency_searched` menghasilkan daftar skill gap di talent pool.

---

## 7. Reporting

### `report_generations` (BARU — audit log untuk fitur "Generate Report")
| Field | Type | Note |
|---|---|---|
| id | uuid PK | |
| generated_by_user_id | uuid FK | |
| portal | enum | `operator`, `corporate_admin`, `employer_verifier` |
| period | text | mis. "This Quarter" |
| sections | jsonb | array section key yang dipilih |
| file_url | text nullable | hasil PDF |
| generated_at | timestamp | |

---

## 8. Multi-Tenancy & Access Control Notes

1. Setiap tabel data spesifik korporat (`trainings` internal, `enrollments`, `employee_profiles`) wajib difilter `company_id` via **Row-Level Security**, bukan hanya filter aplikasi.
2. Konten training internal disimpan di storage bucket **terpisah per company**, signed URL bermasa berlaku pendek — Operator DeAcademy tidak diberi credential akses langsung.
3. `verification_requests`, `portfolio_settings.consent_level`, dan `competency_currency_attestations.verified_by` adalah kontrol privasi yang **wajib divalidasi di backend** sebelum data kompetensi detail di-serialize ke response API untuk verifier.
4. `employee_profiles.employee_id` unik per `company_id` — enforced via composite unique constraint, divalidasi di form "Add Employee".
5. `report_generations` menyimpan jejak audit siapa generate laporan apa, kapan — relevan untuk kepatuhan internal LSP.
