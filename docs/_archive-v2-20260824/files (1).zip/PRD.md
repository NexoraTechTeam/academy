# DeAcademy — Product Requirements Document

**Version:** 2.0 (Full Handoff Draft — reflects all 8 portals)
**Owner:** [Nama Anda / LSP]
**Status:** For development scoping — pending technical review

---

## 1. Background

DeAcademy adalah LMS (Learning Management System) milik sebuah Lembaga Sertifikasi Profesi (LSP), yang berkembang menjadi platform dengan tiga fungsi utama:

1. **LMS pelatihan bersertifikasi** — dijual ke individu maupun korporat, dengan proses assessment lengkap (kuis, exercise, workshop, ujian akhir) dan dua role penilai terpisah: **Tutor** dan **Examiner**.
2. **Portfolio kompetensi & marketplace verifikasi** — peserta membangun rekam jejak kompetensi permanen yang bisa dijadikan referensi melamar kerja, dengan model membership berbayar dan kontrol privasi bertingkat; perusahaan pencari kerja/talent dapat memverifikasi kompetensi kandidat lewat model freemium (info dasar gratis, laporan lengkap berbayar + consent).
3. **LMS-as-a-Service untuk korporat** — perusahaan klien dapat mengelola kompetensi karyawan mereka sepenuhnya di DeAcademy, termasuk membuat **training internal privat** (induction, SOP, kompetensi internal) yang terisolasi penuh dari korporat lain maupun dari staf DeAcademy sendiri.

## 2. Goals & Success Metrics

| Goal | Metric |
|---|---|
| Adopsi platform | Active participants (MoM, YoY), jumlah corporate accounts aktif |
| Revenue (3 aliran) | Training sales, participant memberships, verifier subscriptions |
| Kepatuhan sertifikasi | % CPD compliance, % training compliance korporat, % on-time vs late completion |
| Kepuasan | Satisfaction score — dipisah per segmen (individual vs corporate) |
| Adopsi marketplace verifikasi | Jumlah profile views, verification request, match rate pencarian employer |
| Efisiensi operasional | Turnaround time review tutor/examiner |

## 3. User Roles & Portals

| Role | Deskripsi | Portal (file referensi) |
|---|---|---|
| **Participant** | Individu peserta (mandiri atau karyawan korporat) | `lsp-participant-dashboard.jsx` |
| — | Menjelajah & membeli pelatihan | `lsp-training-catalog.jsx` |
| — | Menjalani pelatihan | `lsp-course-player.jsx` |
| **Tutor** | Menilai Exercise, Workshop; memonitor Quiz (auto-graded) | `lsp-tutor-examiner-review.jsx` |
| **Examiner** | Menilai **hanya** Ujian Akhir Sertifikasi | `lsp-tutor-examiner-review.jsx` |
| **Operator** | Staf internal LSP — kelola seluruh operasi platform | `lsp-operator-dashboard.jsx` |
| **Corporate Admin (PIC)** | HR/L&D perusahaan klien | `lsp-corporate-admin-portal.jsx` |
| **Employer/Verifier** | Perusahaan pihak ketiga pencari/verifikasi kompetensi | `lsp-employer-verifier-portal.jsx` |
| **Public (tanpa login)** | Siapa saja dengan link portfolio peserta | `lsp-public-verification-page.jsx` |

> Satu orang bisa memegang lebih dari satu role (mis. Tutor + Examiner) tergantung penugasan — lihat `ROLES-PERMISSIONS-MATRIX.md`.

## 4. Feature Scope per Portal

### 4.1 Participant Dashboard
- **Dashboard**: skor kompetensi, ringkasan pelatihan & sertifikat, pengingat
- **My Trainings**: berjalan (breakdown kuis/exercise/workshop belum selesai), akan diikuti, rekomendasi
- **Certificates**: 
  - Sumber: LMS-issued / manual upload
  - **Status lifecycle CPD**: Active → Grace Period → Suspended → Lapsed (butuh re-assessment)
  - **Status lifecycle non-CPD**: Active → Attestation Due (tiap 3 tahun) → Dormant — peserta submit **Competency Currency Evidence** (project log/workload letter/work sample), opsional **co-sign dari employer** untuk badge "Employer-Verified"
- **CPD/CPE**: per sertifikasi, kategori dengan cap tahunan, submit aktivitas baru
- **Membership**: plan Free/Premium, harga, **tombol Renew manual**, auto-renew toggle, riwayat tagihan
- **Portfolio & Sharing**:
  - Link publik + toggle publik/privat
  - **3 tingkat consent**: Full Access (auto-approve) / Partial (ringkasan publik saja, tidak pernah full report) / Request-Based (approve manual per request)
  - Visibilitas per sertifikat
  - **Your Visibility**: profile views bulan ini (vs bulan lalu), breakdown via public link vs via employer search
- **Verifier Requests**: daftar & approve/deny permintaan akses laporan lengkap

### 4.2 Training Catalog & Purchase
- Catalog dengan filter kategori, search; detail lengkap (deskripsi, learning objectives, syllabus per modul, prerequisites, audience)
- Cart & checkout: Individual vs Corporate (assign seat ke karyawan setelah checkout)

### 4.3 Course Player
- Struktur: Module → Item (Lesson, Quiz, Exercise, Workshop, Exam)
- **Lesson**: dua tipe konten — **Video** (single file) atau **Slides + Audio** (paginated, narasi per slide, dibuat dari syllabus topics)
- **Quiz**: instant scoring, harus lulus untuk lanjut; setelah lulus → **Review Mode** (read-only) + **Retake for Practice** (tidak mengubah status resmi)
- **Exercise/Workshop**: reference PDF + downloadable template (xlsx/docx/pptx) + upload hasil kerja; **replace submission** sebelum direview; tutor review **in-app view** (bukan download, hemat storage)
- **Exam**: terkunci sampai semua modul selesai, timer, submit → "Awaiting Assessor Review" (tidak auto-final)
- Materi tetap bisa diakses ulang setelah lulus (refresh knowledge)

### 4.4 Tutor & Examiner Workspace
- Role switcher (satu akun bisa dua-duanya, tergantung penugasan & tipe training)
- **Tutor**: grading queue (Exercise/Workshop) — skor + feedback + Approve/Request Revision; Quiz Results read-only
- **Examiner**: hanya antrian Ujian Akhir — skor provisional sistem, keputusan final Competent/Not Yet Competent + komentar

### 4.5 Operator Console
- **Dashboard**: revenue per aliran (training sales, participant memberships, verifier subscriptions) dengan forecast; active participants (bulan/tahun/3 tahun); **Platform Health** (active corporate accounts + pending activation, **Corporate Satisfaction** dan **Individual Satisfaction dipisah**, verifier accounts, premium members)
- **Reports & Analytics**: filter (period/category/segment); Training Portfolio Decision Matrix (Keep/Revise/Discontinue per training + rationale); Competitive Pricing; sebaran wilayah & posisi peserta; Client Concentration (Pareto risk)
- **Participants**, **Trainings** (content editor: deskripsi/objectives/syllabus + **lesson content setup** video/slides+audio; **Related Trainings picker** — searchable multi-select + auto-suggest berbasis kategori yang sama, untuk mengisi rekomendasi "Recommended for You" di sisi peserta tanpa perlu AI di tahap ini)
- **Corporate Accounts**: self-registered vs **provisioning manual oleh operator** (status Pending Activation)
- **Staff Assignments**: penugasan Tutor/Examiner per training/cohort
- **Certificates & CPD**: breakdown per training, active/expiring/no-expiry, jumlah peserta perlu update CPD
- **Generate Report**: pilih periode + section (Revenue, Participants, Training Performance, Corporate Summary, Certificates & CPD, Staff Performance) → export PDF

### 4.6 Corporate Admin Portal (PIC)
- **Dashboard**: training & CPD compliance, satisfaction, progress distribution, **on-time vs late completion breakdown** (dengan warning kalau late >25%)
- **Employees**: **Employee ID unik** + **Department** untuk disambiguasi nama kembar; status training history (sudah ambil training X atau belum, untuk keputusan assign baru vs refresher)
- **Internal Trainings**: builder training privat (deskripsi/objectives/syllabus + lesson content setup) — **tidak muncul di catalog publik, tidak bisa diakses korporat lain, konten tidak bisa dilihat operator DeAcademy** (hanya metadata enrollment/completion yang sync)
- **Assign Training**: dropdown gabungan catalog DeAcademy + internal trainings; search by nama/Employee ID/department; badge riwayat training per karyawan
- **Certificates & CPD**: scoped ke karyawan sendiri
- **Generate Report**: Training Compliance Summary, Employee CPD Status, Internal Training Progress, Certificates Issued

### 4.7 Employer / Verifier Portal
- **Dashboard**: talent profile views (bulan ini, YoY), **Search Match Rate & Skill Gap** (berapa % pencarian menemukan kandidat vs tidak, daftar kompetensi yang dicari tapi tidak ada di talent pool), consent requests (approved/pending/denied)
- **Talent Search**: filter kompetensi, wilayah, **pengalaman kerja** (Entry/Mid/Senior); hanya menampilkan participant yang opt-in publik
- Request full report → notifikasi ke participant → menunggu consent (kecuali Full Access) → **Full Verification Report** (viewable in-platform, plus tombol Download PDF terpisah)
- **Billing**: subscription (unlimited) vs pay-per-request
- **Generate Report**: Talent Search Activity, Match Rate & Skill Gaps, Verification Requests, Billing Summary

### 4.8 Public Verification Page
- Info publik gratis: nama, headline, **pengalaman kerja**, sertifikat aktif + badge verified
- Laporan lengkap berbayar + consent-gated (simulasi toggle auto-approve vs manual approve untuk demo)

## 5. Business Rules Kunci

- **CPD**: 1 jam CPD = 50 menit aktivitas efektif; target tahunan + akumulasi siklus 3 tahun; kategori tertentu (Webinar, Mentoring) punya cap jam/tahun
- **Status Sertifikat (CPD)**: Active → Grace Period (mis. 90 hari) → Suspended → Lapsed (butuh re-assessment, bukan sekadar susul CPD)
- **Status Sertifikat (non-CPD)**: Active → Attestation Due (tiap 3 tahun) → Dormant jika tidak direspons. Bukti: project log / workload letter / work sample, opsional co-sign employer untuk badge lebih kuat
- **Kelulusan Quiz**: threshold skor per quiz, wajib lulus untuk unlock item berikutnya; retake pasca-lulus = practice, tidak mengubah status resmi
- **Ujian akhir**: skor sistem hanya provisional, keputusan final wajib oleh Examiner manusia
- **Tutor vs Examiner**: untuk sertifikasi resmi (mis. BNSP), disarankan orang berbeda demi independensi; untuk training internal boleh sama
- **Consent visibility** (participant): Full Access / Partial / Request-Based — sejalan dengan UU PDP
- **Multi-tenancy**: training internal korporat terisolasi penuh — tidak terlihat korporat lain maupun staf Operator DeAcademy (hanya metadata agregat)
- **Employee ID**: unik per company (bukan global) — wajib divalidasi saat Add Employee untuk disambiguasi nama kembar
- **Report Generation**: setiap laporan yang di-generate (Operator/Corporate/Employer) sebaiknya dicatat di audit log (siapa, kapan, section apa)
- **Training Recommendations**: "Recommended for You" di dashboard peserta bersumber dari relasi `related_trainings` yang dikurasi Operator (manual search + auto-suggest kategori sama) — **bukan** rekomendasi berbasis AI di v1. Model ini sengaja human-curated karena rekomendasi salah punya konsekuensi biaya bagi peserta; upgrade ke similarity search/embedding bisa menggantikan mekanisme auto-suggest di kemudian hari tanpa mengubah UX (operator tetap approve setiap link)

## 6. Non-Functional Requirements

- **Keamanan & Multi-tenancy**: row-level access control berbasis `company_id`; isolasi storage konten training internal
- **Kepatuhan Data**: UU PDP — consent eksplisit untuk berbagi data kompetensi ke pihak ketiga; validasi consent di backend, bukan hanya UI
- **File Storage**: video, audio narasi, PPTX, dokumen exercise/workshop, evidence CPD/currency attestation — object storage + signed URL
- **Konversi Media**: PPTX → slide images/HTML (server-side), transcoding video/audio
- **PDF Generation**: untuk Full Verification Report dan Generate Report di 3 portal manajemen — idealnya render HTML-to-PDF dengan watermark + QR code verifikasi ulang
- **Payment Gateway**: individual, corporate invoicing, subscription recurring (membership peserta & verifier plan)
- **Notifikasi**: email/push untuk reminder CPD, deadline training, verifier request, hasil review, aktivasi corporate account

## 7. Out of Scope (v1)

- Mobile native app
- Integrasi payroll/HRIS korporat
- AI-based proctoring ujian
- Feedback loop "marked as hired" di sisi employer (disebutkan sebagai rekomendasi masa depan, belum diimplementasi di prototype)

## 8. Open Questions

- Default consent level untuk peserta baru: Request-Based atau Partial?
- Apakah Operator DeAcademy butuh modul "Internal Training" terpisah untuk pelatihan staf mereka sendiri (paralel dengan Corporate Admin)?
- Kebijakan refund untuk verifier request yang di-deny peserta?
- Siapa yang berwenang memverifikasi Competency Currency Attestation untuk peserta individu (non-corporate) — Operator, atau tetap self-attested?
